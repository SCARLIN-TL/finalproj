import PocketBase from 'pocketbase';

const pb = new PocketBase('http://192.168.7.10:8090'); // replace with your Pi's IP if needed
export default pb;
