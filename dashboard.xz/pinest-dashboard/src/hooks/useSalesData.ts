import { useEffect, useState } from 'react';
import pb from './usePocketBase';

type Order = {
  created: string;
  total: number;
};

type SalesPoint = {
  date: string;
  total: number;
};

export const useSalesData = () => {
  const [data, setData] = useState<SalesPoint[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const records = await pb.collection('orders').getFullList<Order>({
          sort: 'created',
        });

        // Group by date
        const grouped: { [date: string]: number } = {};
        for (const order of records) {
          const date = new Date(order.created).toISOString().split('T')[0];
          grouped[date] = (grouped[date] || 0) + order.total;
        }

        const result: SalesPoint[] = Object.entries(grouped).map(([date, total]) => ({
          date,
          total,
        }));

        setData(result);
      } catch (err) {
        console.error('Error loading sales data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, []);

  return { data, loading };
};
