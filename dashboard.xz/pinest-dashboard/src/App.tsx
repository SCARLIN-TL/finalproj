import { useSalesData } from './hooks/useSalesData';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from 'recharts';

function App() {
  const { data, loading } = useSalesData();

  return (
    <div className="p-6 font-sans">
      <h1 className="text-2xl font-bold mb-4">📊 PiNest Sales Overview</h1>

      {loading ? (
        <p>Loading sales data...</p>
      ) : (
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="total" stroke="#3b82f6" strokeWidth={2} />
          </LineChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}

export default App;
