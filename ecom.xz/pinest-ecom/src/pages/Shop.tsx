import { useInventory } from '../hooks/useInventory';
import { useCart } from '../context/CartContext';

function Shop() {
  const { products, loading } = useInventory();
  const { addToCart } = useCart();

  const getImageUrl = (product: any) => {
    if (!product.image) return null;
    return `http://192.168.7.10:8090/api/files/inventory/${product.id}/${product.image}`;
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Shop</h1>
      {loading ? (
        <p>Loading products...</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((item) => (
            <div key={item.id} className="border p-4 rounded shadow flex flex-col">
              {item.image && (
                <img
                  src={getImageUrl(item)}
                  alt={item.name}
                  className="w-full h-48 object-cover rounded mb-2"
                />
              )}
              <h2 className="text-xl font-semibold">{item.name}</h2>
              <p className="text-sm text-gray-600 mb-2">{item.description}</p>
              <p className="text-lg font-bold">${item.price.toFixed(2)}</p>
              <p className="text-sm mb-2">Stock: {item.quantity}</p>
              <button
                onClick={() => addToCart({ ...item, quantity: 1 })}
                className="mt-auto px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
              >
                Add to Cart
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Shop;
