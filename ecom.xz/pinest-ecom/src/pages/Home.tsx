function Home() {
    return (
      <div className="p-6">
        <h1 className="text-2xl font-bold">Welcome to PiNest</h1>
        <p>Explore our collection of Raspberry Pi accessories.</p>
      </div>
    );
  }
  
  export default Home;

  