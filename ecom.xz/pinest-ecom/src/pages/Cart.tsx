import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import pb from '../hooks/usePocketBase';
import { useNavigate } from 'react-router-dom';

function Cart() {
  const { cart, updateQuantity, removeFromCart, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleCheckout = async () => {
    if (!user) return navigate('/login');
  
    try {
      // 1. Save the order
      await pb.collection('orders').create({
        user: user.id,
        items: cart,
        total,
        status: 'pending',
      });
  
      // 2. Update inventory stock
      for (const item of cart) {
        try {
          const current = await pb.collection('inventory').getOne(item.id);
          const newQuantity = Math.max(0, current.quantity - item.quantity);
  
          await pb.collection('inventory').update(item.id, {
            quantity: newQuantity,
          });
        } catch (err) {
          console.error(`❌ Failed to update stock for ${item.name}:`, err);
        }
      }
  
      clearCart();
      alert('✅ Order placed!');
      navigate('/shop');
    } catch (err) {
      console.error('❌ Checkout failed:', err);
      alert('Something went wrong during checkout.');
    }
  };
  

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Your Cart</h1>

      {cart.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <>
          {cart.map((item) => (
            <div key={item.id} className="flex justify-between items-center mb-4 border-b pb-2">
              <div>
                <h2 className="font-semibold">{item.name}</h2>
                <p className="text-sm text-gray-600">${item.price.toFixed(2)}</p>
              </div>
              <input
                type="number"
                value={item.quantity}
                min={1}
                max={item.quantity + 10}
                onChange={(e) => updateQuantity(item.id, parseInt(e.target.value))}
                className="w-16 px-2 py-1 border rounded"
              />
              <button
                onClick={() => removeFromCart(item.id)}
                className="text-red-600 hover:underline ml-4"
              >
                Remove
              </button>
            </div>
          ))}

          <div className="mt-6 flex justify-between items-center">
            <p className="text-lg font-bold">Total: ${total.toFixed(2)}</p>
            <button
              onClick={handleCheckout}
              className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
            >
              Checkout
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export default Cart;
