import { useEffect, useState } from 'react';
import pb from './usePocketBase';

export type Product = {
  id: string;
  name: string;
  description: string;
  price: number;
  quantity: number;
  image?: string;
};

export const useInventory = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchInventory = async () => {
      try {
        console.log('📦 Fetching inventory from PocketBase...');
        const result = await pb.collection('inventory').getList<Product>(1, 50);
        console.log('✅ Products fetched:', result.items);
        setProducts(result.items);
      } catch (err) {
        console.error('❌ Error fetching inventory:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchInventory();
  }, []);

  return { products, loading };
};
