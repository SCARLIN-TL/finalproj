import PocketBase from 'pocketbase';

// Replace with your Pi's IP address
const pb = new PocketBase('http://192.168.7.10:8090');

console.log('PocketBase client initialized:', pb);

export default pb;
