import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Shop from './pages/Shop';
import Login from './pages/Login';
import Register from './pages/Register';
import Cart from './pages/Cart';
import { useAuth } from './context/AuthContext';
import { useCart } from './context/CartContext';

function App() {
  const { user, logout } = useAuth();
  const { cart } = useCart();

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <Router>
      <nav className="p-4 bg-gray-100 flex gap-4 shadow items-center">
        <Link to="/" className="font-semibold text-blue-600 hover:underline">Home</Link>
        <Link to="/shop" className="font-semibold text-blue-600 hover:underline">Shop</Link>
        <Link to="/cart" className="relative font-semibold text-blue-600 hover:underline">
          Cart
          {cartCount > 0 && (
            <span className="ml-1 bg-red-500 text-white text-xs rounded-full px-2 py-0.5">
              {cartCount}
            </span>
          )}
        </Link>

        <div className="ml-auto flex gap-4 items-center">
          {user ? (
            <>
              <span className="text-sm text-gray-700">Hi, {user.username}</span>
              <button
                onClick={logout}
                className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600"
              >
                Log out
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="font-semibold text-blue-600 hover:underline">Login</Link>
              <Link to="/register" className="font-semibold text-blue-600 hover:underline">Register</Link>
            </>
          )}
        </div>
      </nav>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/shop" element={<Shop />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Routes>
    </Router>
  );
}

export default App;
