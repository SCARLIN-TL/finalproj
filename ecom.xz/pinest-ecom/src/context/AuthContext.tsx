import { createContext, useContext, useEffect, useState } from 'react';
import pb from '../hooks/usePocketBase';
import type { RecordModel } from 'pocketbase';

type AuthContextType = {
  user: RecordModel | null;
  login: (emailOrUsername: string, password: string) => Promise<void>;
  register: (email: string, username: string, password: string) => Promise<void>;
  logout: () => void;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<RecordModel | null>(pb.authStore.model);

  useEffect(() => {
    const unsubscribe = pb.authStore.onChange(() => {
      setUser(pb.authStore.model);
    });
    return unsubscribe;
  }, []);

  const login = async (emailOrUsername: string, password: string) => {
    await pb.collection('ecomusers').authWithPassword(emailOrUsername, password);
    setUser(pb.authStore.model);
  };

  const register = async (email: string, username: string, password: string) => {
    await pb.collection('ecomusers').create({
      email,
      username,
      password,
      passwordConfirm: password,
    });

    // Auto-login after registration
    await login(email, password);
  };

  const logout = () => {
    pb.authStore.clear();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};
